import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {map} from 'rxjs/operators';
import { Loan } from './loan';
@Injectable({
  providedIn: 'root'
})
export class LoanserviceService {

  constructor(private http:HttpClient) { }
    getUserDetails(){
      var cust_id=localStorage.getItem('token');
      
      return this.http.get('http://localhost:8090/cust_project/Customer/Loan/'+cust_id);
    }
}
