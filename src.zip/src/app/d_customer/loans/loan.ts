export class Loan{
	loan_Acc_no:string;
	open_date:string;
	close_date:string;
	issue_amount:number;
	balance:number;
	loan_type:string;
	interest_rate:number;
	cust_id:number;
	account_no:number;
	approval:number;
	constructor(loan_Acc_no:string,	open_date:string,close_date:string,issue_amount:number,balance:number,loan_type:string,interest_rate:number,cust_id:number,account_no:number,approval:number){
			this.loan_Acc_no=loan_Acc_no;
			this.open_date=open_date;
			this.close_date=close_date;
			this.issue_amount=issue_amount;
			this.balance=balance;
			this.loan_type=loan_type;
			this.interest_rate=interest_rate;
			this.cust_id=cust_id;
			this.account_no=account_no;
			this.approval=approval;

	}
}