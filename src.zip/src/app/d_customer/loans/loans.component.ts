import { Component, OnInit } from '@angular/core';
import { LoanserviceService } from './loanservice.service';
import { Loan } from './loan';
import { Router } from '@angular/router';
import {AuthService} from '../../auth.service';
@Component({
  selector: 'app-loans',
  templateUrl: './loans.component.html',
  styleUrls: ['./loans.component.css']
})
export class LoansComponent implements OnInit {
  mod=new Loan('','','',0,0,'',0,0,0,0);
  constructor(private router: Router,private _httpService:LoanserviceService,public authService: AuthService) { }

  ngOnInit() {

      this._httpService.getUserDetails().subscribe((res:any[])=>{
      var x=JSON.parse(JSON.stringify(res));
      console.log(x);
      for (var i = 0; i < x.length; i++) {
        
        this.mod.account_no=x[i].account_no;
        this.mod.interest_rate=x[i].interest_rate;
        this.mod.issue_amount=x[i].issue_amount;
        this.mod.balance=x[i].balance;
        
        this.mod.open_date=x[i].open_date;
        this.mod.loan_type=x[i].loan_id;
        
      }
     
    })
      this.mod.close_date="2019-01-10";
  }
  logout(): void {
    console.log("Logout");
    this.authService.logout();
    this.router.navigate(['login']);
  }

}
