import {HttpClient} from '@angular/common/http';
import {map} from 'rxjs/operators';
import { d_Customer } from '../Customer';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BalanceserviceService {
  
  constructor(private http:HttpClient) { }
  getUserDetails(){
    var cust_id=localStorage.getItem('cust_id');
  	return this.http.get('http://localhost:8090/cust_project/Customer/Balance/'+cust_id);
  }
}
