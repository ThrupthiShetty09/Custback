import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { d_ProfileComponent } from './profile.component';

describe('ProfileComponent', () => {
  let component: d_ProfileComponent;
  let fixture: ComponentFixture<d_ProfileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ d_ProfileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(d_ProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
