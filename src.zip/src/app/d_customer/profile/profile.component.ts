import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {map} from 'rxjs/operators';
import { ProfileserviceService } from './profileservice.service';
import { Customer } from './Customer';
import { NgModule } from "@angular/core";
import {AuthService} from '../../auth.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class d_ProfileComponent implements OnInit {
  customerForm: FormGroup;
  submitted = false;
  mod=new Customer(0,0,'',0,0,'','','',0,'');
  constructor(private formBuilder: FormBuilder,private router: Router,private _httpService:ProfileserviceService,public authService: AuthService) { }

  ngOnInit() {

  
       


      //reactive form validation 
          this.customerForm = this.formBuilder.group({
            name: ['', [Validators.required,Validators.minLength(3)]],
            account_no: ['', [Validators.required,Validators.minLength(5)]],
            address: ['', [Validators.required,Validators.minLength(30)]],
            dob: ['', Validators.required],
            contact: ['', [Validators.required,Validators.minLength(10),Validators.maxLength(10)]],
            username: ['', [Validators.required,Validators.minLength(4)]],
            password: ['', [Validators.required,Validators.minLength(6)]],
            adhar_number: ['', [Validators.required,Validators.minLength(12)]],
            pan_number: ['', [Validators.required,Validators.minLength(10)]]
           
        });
        



        var accArray = new Array();
  	    this._httpService.getUserDetails().subscribe((res:any[])=>{
        var x=JSON.parse(JSON.stringify(res));
        console.log(x);
        for (var i = 0; i < x.length; i++) {
        	accArray.push(x[i].account_no);
        }
        this.mod.account_no=x[0].account_no;;
        this.mod.name=x[0].name;
        this.mod.dob=x[0].dob;
        this.mod.contact=x[0].contact;
        this.mod.address=x[0].address;
        this.mod.username=x[0].username;
        this.mod.password=x[0].password;
        this.mod.adhar_number=x[0].adhar_number;
        this.mod.pan_number=x[0].pan_number;
       	this.mod.cust_id=x[0].cust_id;
      })
  }

  get f() { return this.customerForm.controls; }
        onSubmit() {
          this.submitted = true;
         
          // stop here if form is invalid
          if (this.customerForm.invalid) {
              return;
          }else{
            
            this._httpService.setUserDetails(this.mod.cust_id,this.mod).subscribe( data => {    
            })
            alert("successfull");
            window.location.reload();
            
          }
      }
      logout(): void {
        console.log("Logout");
        this.authService.logout();
        this.router.navigate(['login']);
      }
}
