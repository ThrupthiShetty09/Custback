export class Transaction{
	trans_id:number;
	trans_date:string;
	trans_time:string;
	debit:number;
	credit: number;
	account_no:number;
	constructor(trans_id:number,trans_date:string,trans_time:string,credit: number,debit:number,account_no:number){
		this.trans_id=trans_id;
		this.trans_date=trans_date;
		this.trans_time=trans_time;
		this.credit=credit;
		this.debit=debit;
		this.account_no=account_no;
		
	}
}