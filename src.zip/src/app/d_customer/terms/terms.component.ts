import { Component, OnInit } from '@angular/core';
import {AuthService} from '../../auth.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-terms',
  templateUrl: './terms.component.html',
  styleUrls: ['./terms.component.css']
})
export class TermsComponent implements OnInit {

  constructor(private router: Router,public authService: AuthService) { }

  ngOnInit() {
  }
  logout(): void {
    console.log("Logout");
    this.authService.logout();
    this.router.navigate(['login']);
  }

}
