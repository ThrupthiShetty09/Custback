import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {map} from 'rxjs/operators';
import { LoanRequest } from './LoanRequest';
@Injectable({
  providedIn: 'root'
})
export class RequestloanService {

  constructor(private http:HttpClient) { }
    getUserDetails(){
      return this.http.get('http://localhost:8090/cust_project/Customer/123456');
    }
    setUserDetails(acc:number,cust:object){
      console.log(cust);
      return this.http.put<LoanRequest>('http://localhost:8090/cust_project/put/Customer/Loan/123457/'+acc,cust);
  
    }
}
