import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RequestloanService } from './requestloan.service';
import { LoanRequest } from './LoanRequest';
import { NgModule } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {AuthService} from '../../auth.service';
@Component({
  selector: 'app-request-loan',
  templateUrl: './request-loan.component.html',
  styleUrls: ['./request-loan.component.css']
})
export class RequestLoanComponent implements OnInit {
  customerForm: FormGroup;
  submitted = false;
  mod =new LoanRequest('','','',0,'','',0,0,0,0);
  constructor(private formBuilder: FormBuilder,private router: Router,private _httpService:RequestloanService,public authService: AuthService) { }

  ngOnInit() {

        //reactive form validation 
        this.customerForm = this.formBuilder.group({
          account_no: ['', [Validators.required,Validators.minLength(5)]],
          open_date: ['', Validators.required],
          close_date: ['', Validators.required],
          issue_amount: ['',Validators.required],
          loan_type: ['',Validators.required],
                 
      });

      this._httpService.getUserDetails().subscribe((res:any[])=>{
      var x=JSON.parse(JSON.stringify(res));
      console.log(x);
      for (var i = 0; i < x.length; i++) {
        this.mod.account_no=x[i].account_no;
        //this.mod.cust_id=x[i].cust_id;
        // this.mod.loan_Acc_no=x[i].account_no;
        // this.mod.interest_rate=x[i].interest_rate;
        // this.mod.issue_amount=x[i].issue_amount;
        // this.mod.balance=x[i].balance;
        // this.mod.close_date=x[i].close_date;
        // this.mod.open_date=x[i].open_date;
        // this.mod.loan_type=x[i].loan_id;
        
      }
     
    })

  }

  get f() { return this.customerForm.controls; }
        onSubmit() {
          this.submitted = true;
         
          // stop here if form is invalid
          if (this.customerForm.invalid) {
              return;
          }else{
            
            this._httpService.setUserDetails(this.mod.cust_id,this.mod).subscribe( data => {    
            })
            alert("successfull");
            window.location.reload();
            
          }
      }
      logout(): void {
        console.log("Logout");
        this.authService.logout();
        this.router.navigate(['login']);
      }
}
