import { TestBed } from '@angular/core/testing';

import { RequestloanService } from './requestloan.service';

describe('RequestloanService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RequestloanService = TestBed.get(RequestloanService);
    expect(service).toBeTruthy();
  });
});
