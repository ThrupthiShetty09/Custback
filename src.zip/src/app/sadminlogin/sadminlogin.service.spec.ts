import { TestBed } from '@angular/core/testing';

import { SadminloginService } from './sadminlogin.service';

describe('SadminloginService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SadminloginService = TestBed.get(SadminloginService);
    expect(service).toBeTruthy();
  });
});
