import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {MainpageComponent}  from './mainpage/mainpage.component';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './c_login/login.component';
import {ApproveloanComponent} from './c_agentmain/approveloan/approveloan.component'
import {AgentcomponentComponent} from './c_agentmain/c_agentcomponent/agentcomponent.component'
import {AgentprofileComponent} from './c_agentmain/c_agentprofile/agentprofile.component'
import {ApproveCustComponent} from './c_agentmain/c_approve-cust/approve-cust.component'
import {ViewcustomerComponent} from './c_agentmain/c_viewcustomer/viewcustomer.component'
import {ViewtransactionComponent} from './c_agentmain/c_viewtransaction/viewtransaction.component'
import {AgentmainComponent} from './c_agentmain/agentmain.component'
import {CustomerProfileComponent} from './customer-profile/customer-profile.component'
import { AuthGuard } from './auth.guard';
import { RouterModule, Routes } from '@angular/router';
import { AgGridModule } from '@ag-grid-community/angular';
import  {b_LoginComponent} from './b_login/login.component';
import  {TermsComponent} from './terms/terms.component';
import  {MdupdateComponent} from './mdupdate/mdupdate.component';
import  {ManagerComponent} from './manager/manager.component';
import  {MRegistrationComponent} from './m-registration/m-registration.component';
import  {FaqComponent} from './faq/faq.component';

import {DashboardComponent} from './dashboard/dashboard.component';
import {b_CustomerComponent} from './b_customer/customer.component';


import { CeoMainPageComponent } from './ceo-main-page/ceo-main-page.component';
import { AboutusComponent } from './ceo-main-page/aboutus/aboutus.component';
import { LoanComponent } from './ceo-main-page/loan/loan.component';
import { BranchComponent } from './ceo-main-page/branch/branch.component';
import { AdminComponent } from './ceo-main-page/admin/admin.component';
import { ProfileComponent } from './ceo-main-page/profile/profile.component';
import { RegisterComponent } from './ceo-main-page/admin/register/register.component';
import { SadminloginComponent } from './sadminlogin/sadminlogin.component';
import { RegisterloanComponent } from './ceo-main-page/admin/registerloan/registerloan.component';

import { d_CustomerComponent } from './d_customer/customer.component';
import { d_ProfileComponent } from './d_customer/profile/profile.component';
import { BalanceComponent } from './d_customer/balance/balance.component';
import { TransferComponent } from './d_customer/transfer/transfer.component';
import { LoansComponent } from './d_customer/loans/loans.component';
import { MiniComponent } from './d_customer/mini/mini.component';
import { RequestLoanComponent } from './d_customer/request-loan/request-loan.component';
import { d_LoginComponent } from './login/login.component';
import {AgentregistrationComponent} from './b_agentregistration/agentregistration.component'
import { HttpClientModule } from '@angular/common/http';
import { GridModule } from '@syncfusion/ej2-angular-grids';
import { PageService, SortService, FilterService, GroupService } from '@syncfusion/ej2-angular-grids';
const appRoutes: Routes = [
  { path: 'c_login', component: LoginComponent },
  { path: 'b_login', component: b_LoginComponent },
  { path: 'c_agentmain', component: AgentmainComponent, canActivate: [AuthGuard] }
];
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    AgentregistrationComponent,
    MainpageComponent,
    ApproveloanComponent,
    AgentcomponentComponent,
    AgentprofileComponent,
    ApproveCustComponent,
    ViewcustomerComponent,
    ViewtransactionComponent,
    AgentmainComponent,
    CustomerProfileComponent,
    b_LoginComponent,
    TermsComponent,
    MdupdateComponent,
    ManagerComponent,
    MRegistrationComponent,
    FaqComponent,
    b_CustomerComponent,
    DashboardComponent,


    CeoMainPageComponent,
    AboutusComponent,
    LoanComponent,
    BranchComponent,
    AdminComponent,
    ProfileComponent,
    RegisterComponent,
    SadminloginComponent,
    RegisterloanComponent,

 d_CustomerComponent,
    d_ProfileComponent,
    BalanceComponent,
    TransferComponent,
    LoansComponent,
    MiniComponent,
    RequestLoanComponent,
    d_LoginComponent,

  ],
  imports: [
   BrowserModule,
    AppRoutingModule,
    AgGridModule.withComponents([]),
    FormsModule,
      ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forRoot(appRoutes),
    GridModule

  ],
  providers: [AuthGuard,PageService, SortService, FilterService, GroupService],
  bootstrap: [AppComponent]
})
export class AppModule { }
