export class Loan{
	
	public loan_id:number;
	public loan_type:string;
	public loan_irate: number;
	public loan_desc: string;
	
	constructor(loan_type:string,loan_irate: number,loan_desc: string)
	{	
		this.loan_type = loan_type;
		this.loan_irate = loan_irate;
		this.loan_desc = loan_desc;
		
		
	}
}
