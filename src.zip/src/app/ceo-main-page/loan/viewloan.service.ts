import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { Loan } from './loan';

@Injectable({
  providedIn: 'root'
})
export class ViewloanService {

  constructor(private http: HttpClient) { }

  getLoans() {
   return this.http.get('http://localhost:8090/cust_project/loan');
    
  }

  createLoans(loan: Object): Observable<Object>{
  	console.log(loan);
    return this.http.post<Loan>('http://localhost:8090/cust_project/post/loan/', loan);
    
  }

  delLoan(loan_no){
  	console.log(loan_no);
    return this.http.delete('http://localhost:8090/cust_project/delete/loan/'+ loan_no, loan_no);
    
  }

  updateLoan(loan_no : number,loan: Object) {
  	console.log(loan_no);
  	console.log(loan);
    return this.http.put<Loan>('http://localhost:8090/cust_project/put/loan/'+ loan_no, loan);
    
  }
}
