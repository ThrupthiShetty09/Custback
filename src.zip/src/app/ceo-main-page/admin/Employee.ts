export class Employee{
	
	public empId:number;
	public name:string;
	public dob: string;
	public contact: number;
	public email:string;
	public username: string;
	public pwd: string;
	public role:string;

	
	

	constructor(name:string,dob: string,contact: number,email:string,username: string,pwd: string,role:string)
	{	
		this.name=name;
		this.dob=dob;
		this.contact=contact;
		this.email = email;
		this.username=username;
		this.pwd=pwd;
		this.role=role;
	}
}
