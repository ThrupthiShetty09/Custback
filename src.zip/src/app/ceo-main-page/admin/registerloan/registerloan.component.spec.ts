import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegisterloanComponent } from './registerloan.component';

describe('RegisterloanComponent', () => {
  let component: RegisterloanComponent;
  let fixture: ComponentFixture<RegisterloanComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegisterloanComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegisterloanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
