import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registerloan',
  templateUrl: './registerloan.component.html',
  styleUrls: ['./registerloan.component.css']
})
export class RegisterloanComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
