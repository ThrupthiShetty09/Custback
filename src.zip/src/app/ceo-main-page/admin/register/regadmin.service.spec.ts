import { TestBed } from '@angular/core/testing';

import { RegadminService } from './regadmin.service';

describe('RegadminService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RegadminService = TestBed.get(RegadminService);
    expect(service).toBeTruthy();
  });
});
