import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { Employee } from './Employee';

@Injectable({
  providedIn: 'root'
})
export class AdminserviceService {

  constructor(private http: HttpClient) { }

  getSuperuserDetails() {
    return this.http.get('http://localhost:8090/cust_project/employee');
    //return this.http.get('http://localhost:8080/A_MyProject/employee');
  }

  delEmployee(emp_no){
  	console.log(emp_no);
    return this.http.delete('http://localhost:8090/cust_project/delete/employee/'+ emp_no, emp_no);
    //return this.http.delete('http://localhost:8080/A_MyProject/delete/employee/'+ emp_no, emp_no);
  }

  updateEmployee(emp_no : number,employee: Object) {
  	console.log(emp_no);
  	console.log(employee);
    return this.http.put<Employee>('http://localhost:8090/cust_project/put/employee/'+ emp_no, employee);
    //return this.http.put<Employee>('http://localhost:8080/A_MyProject/put/employee/'+ emp_no, employee);
  }
}
