import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-ceo-main-page',
  templateUrl: './ceo-main-page.component.html',
  styleUrls: ['./ceo-main-page.component.css']
})
export class CeoMainPageComponent implements OnInit {

  constructor(private router: Router) {/* Set the width of the side navigation to 250px */
 }

  ngOnInit() {
  

	}

	about(){
		this.router.navigate(['/ceo-main-page']);
	}
	loan(){
		this.router.navigate(['/loan']);
	}
	branch(){
		this.router.navigate(['/branch']);
	}
	admin(){
		this.router.navigate(['/admin']);
	}
profile(){
	this.router.navigate(['/profile']);
}
logout(){
  this.router.navigate(['/a_login']);
}
}

