import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CeoMainPageComponent } from './ceo-main-page.component';

describe('CeoMainPageComponent', () => {
  let component: CeoMainPageComponent;
  let fixture: ComponentFixture<CeoMainPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CeoMainPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CeoMainPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
