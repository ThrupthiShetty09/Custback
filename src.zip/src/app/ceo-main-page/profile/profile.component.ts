import { Component, OnInit } from '@angular/core';
import { Employee } from '../admin/Employee';
import { ProfileService } from './profile.service';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  getData:any;
  constructor(private router: Router, private http: HttpClient, private _httpService : ProfileService) { 

  	this._httpService.getSuperuserDetails()
		.subscribe((res : any[])=>{
			console.log(res);

			this.getData = res;
	});
  }

  ngOnInit() {
  }
home3(){
  this.router.navigate(['ceo-main-page']);
}

logout(){
  this.router.navigate(['/a_login']);
}
}
