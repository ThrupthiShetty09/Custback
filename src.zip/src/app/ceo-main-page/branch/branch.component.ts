import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Branch } from './branch';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BranchserviceService } from './branchservice.service';
import { AllCommunityModules } from '@ag-grid-community/all-modules';
import { AgGridAngular } from '@ag-grid-community/angular';
@Component({
  selector: 'app-branch',
  templateUrl: './branch.component.html',
  styleUrls: ['./branch.component.css']
})
export class BranchComponent implements OnInit {

	getData:any[];

	name: string;
	ifsc: string;
	address: string;
	contact:number;
	
	
	emprole: "Regional Manager";
	branch : Branch;  
	submitted = false;
	//registerForm: FormGroup;
	namepattern = "^[A-Za-z]+$";
	private gridApi;
  private gridColumnApi;

  model =  new Branch('','','',0);

  constructor(private router: Router,private http: HttpClient,private __httpService :BranchserviceService,private formBuilder: FormBuilder ) {

  	this.__httpService.getBranchDetails()
        .subscribe((res : any[])=>{
            console.log(res);

            this.getData = res;
        });


  }

  columnDefs = [
         
         
         {  headerName: "Branch Id",field: "br_id",width:100, sortable:true,filter:true , checkboxSelection:true},
         {  headerName: "Branch name",field: "br_name",width:95,sortable:true,filter:true },
         {  headerName: "Brandh IFSC",field: "br_ifsc",width:110, sortable:true,filter:true },
         {  headerName: "Branch Address",field: "br_addr",width:150,sortable:true,filter:true},
         {  headerName: "Branch Contact",field: "br_contact",width:150,sortable:true,filter:true}
       
        
         
        
        

      ];

    rowData: any;

  registerForm = this.formBuilder.group({
		bname: ['', [Validators.required,Validators.pattern(this.namepattern)]],
		bifsc: ['', Validators.required],
		bcontact: ['', [Validators.required,Validators.pattern(/^[0-9]{10}$/)] ],
		baddr: ['', [Validators.required] ],
		
});

  ngOnInit() {
  	//this.rowData = this.http.get('http://localhost:8080/A_MyProject/branch');
    this.rowData = this.http.get('http://localhost:8090/cust_project/branch');
  }

	onGridReady(params) {
        this.gridApi = params.api;
        this.gridColumnApi = params.columnApi;
      }
  createBranch(){
		var check = this.save();
		if(check) {
			
			//this.router.navigate(['ceo-main-page']);
    location.reload();
		}
		else {
			return;
		}

		    
	}

	get f() { 
		return this.registerForm.controls; 
	} 

	save(): boolean {
		

      	if (this.registerForm.invalid) {
      		//alert("INSIDE");
      		this.submitted = true;
			//alert("Please enter");
			return false;
        }
        else {
        	//alert("ELSE IF");
        	this.submitted = false;
        	this.name = this.f.bname.value;
        	console.log(this.name);

			this.ifsc = this.f.bifsc.value;
			this.address = this.f.baddr.value;
			this.contact = this.f.bcontact.value;
			
			this.branch = new Branch(this.name,this.ifsc,this.address,this.contact);
			this.__httpService.createBranches(this.branch)
	      		.subscribe(data => console.log(data), error => console.log(error));
	        return true;
      	 
      	 //this.router.navigate(['a_listadmin']);
      	}
	}

	onRemoveSelected() {
        var selectedData = this.gridApi.getSelectedRows();
        console.log(selectedData[0].br_id);
        this.__httpService.delBranch(selectedData[0].br_id)
              .subscribe(data => console.log(data), error => console.log(error));

        location.reload();

        //var id = selectedData
    }

    updateSelected() {
        var selectedData = this.gridApi.getSelectedRows();
        //console.log(selectedData);
        //this.id = selectedData[0].empId;
        this.model.br_id = selectedData[0].br_id;
        this.model.br_name = selectedData[0].br_name;
        this.model.br_ifsc = selectedData[0].br_ifsc;
        this.model.br_contact = selectedData[0].br_contact;
        this.model.br_addr = selectedData[0].br_addr;
        

    
    }

    updRow(){
        //var uData = [];
        //var id = this.updateSelected();
        //new Employee(this.name,this.dob,this.phno,this.email,this.username,this.password,this.role);
        this.branch = new Branch(this.model.br_name,this.model.br_ifsc,this.model.br_addr,this.model.br_contact);
        this.branch.br_id = this.model.br_id;
        //console.log(this.employee);
        //console.log(id);
        this.__httpService.updateBranch(this.model.br_id,this.branch).subscribe(data => console.log(data));
         
         //this.router.navigate(['a_main-page']);  
         location.reload();
    }

    home3(){
  this.router.navigate(['ceo-main-page']);
}

logout(){
  this.router.navigate(['/a_login']);
}

    
    modules = AllCommunityModules;

}
