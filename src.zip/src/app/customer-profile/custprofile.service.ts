import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {map} from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class CustprofileService {
constructor(private http:HttpClient) { }
   getProfiledetails(id) {
      return this.http.get('http://localhost:8090/cust_project/c_agent/'+id);
  }
  deleteAgents(empid)
  {
    console.log(empid);
    return this.http.delete('http://localhost:8090/cust_project/delete/c_agent/'+empid,empid);
  }
 UpdateAgents(id)
  {
    return this.http.get('http://localhost:8090/cust_project/c_agent/'+id);
  }
   getCustdetails(id,id1) {
      return this.http.get('http://localhost:8090/cust_project/c_customer1/'+id+'/'+id1);
  }
  UpdateCustomer(agent,id)
  {
    return this.http.put('http://localhost:8090/cust_project/put/c_customer/'+id,agent,id);
  }
}
