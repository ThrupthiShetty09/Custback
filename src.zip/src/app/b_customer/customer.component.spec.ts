import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { b_CustomerComponent } from './customer.component';

describe('b_CustomerComponent', () => {
  let component: b_CustomerComponent;
  let fixture: ComponentFixture<b_CustomerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ b_CustomerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(b_CustomerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
