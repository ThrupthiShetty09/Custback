import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Agent } from './agent';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AgentregistrationserviceService {

  constructor(private http:HttpClient) { }

  createAgent(agent){
  	console.log(agent);
  	return this.http.post('http://localhost:8090/cust_project/post/customer',agent);
  }
}
