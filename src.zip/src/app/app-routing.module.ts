import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {MainpageComponent}  from './mainpage/mainpage.component';
import  {LoginComponent} from './c_login/login.component'
import  {b_LoginComponent} from './b_login/login.component'
import { GridModule } from '@syncfusion/ej2-angular-grids';
import  {TermsComponent} from './terms/terms.component';
import  {MdupdateComponent} from './mdupdate/mdupdate.component';
import  {ManagerComponent} from './manager/manager.component';
import  {MRegistrationComponent} from './m-registration/m-registration.component';
import  {FaqComponent} from './faq/faq.component';
import {DashboardComponent} from './dashboard/dashboard.component';
import {ApproveloanComponent} from './c_agentmain/approveloan/approveloan.component'
import {AgentcomponentComponent} from './c_agentmain/c_agentcomponent/agentcomponent.component'
import {AgentprofileComponent} from './c_agentmain/c_agentprofile/agentprofile.component'
import {ApproveCustComponent} from './c_agentmain/c_approve-cust/approve-cust.component'
import {ViewcustomerComponent} from './c_agentmain/c_viewcustomer/viewcustomer.component'
import {ViewtransactionComponent} from './c_agentmain/c_viewtransaction/viewtransaction.component'
import {AgentmainComponent} from './c_agentmain/agentmain.component'
import {CustomerProfileComponent} from './customer-profile/customer-profile.component'
import {AgentregistrationComponent} from './b_agentregistration/agentregistration.component'
import {b_CustomerComponent} from './b_customer/customer.component';

import { CeoMainPageComponent } from './ceo-main-page/ceo-main-page.component';
import { AboutusComponent } from './ceo-main-page/aboutus/aboutus.component';
import { LoanComponent } from './ceo-main-page/loan/loan.component';
import { BranchComponent } from './ceo-main-page/branch/branch.component';
import { AdminComponent } from './ceo-main-page/admin/admin.component';
import { ProfileComponent } from './ceo-main-page/profile/profile.component';
import { RegisterComponent } from './ceo-main-page/admin/register/register.component';
import { SadminloginComponent } from './sadminlogin/sadminlogin.component';
import { RegisterloanComponent } from './ceo-main-page/admin/registerloan/registerloan.component';
import { d_CustomerComponent } from './d_customer/customer.component';
import { d_ProfileComponent } from './d_customer/profile/profile.component';
import { BalanceComponent } from './d_customer/balance/balance.component';
import { TransferComponent } from './d_customer/transfer/transfer.component';
import { LoansComponent } from './d_customer/loans/loans.component';
import { MiniComponent } from './d_customer/mini/mini.component';
import { RequestLoanComponent } from './d_customer/request-loan/request-loan.component';
import { d_LoginComponent } from './login/login.component'

const routes: Routes = [
{ path:'',redirectTo:'mainpage',pathMatch:'full'},
 { path:'mainpage', component:MainpageComponent },
 { path:'regform', component:AgentregistrationComponent},
 {path:'c_login',component:LoginComponent},
  {path:'b_login',component:b_LoginComponent},

 {path:'approveloan',component:ApproveloanComponent},
 {path:'c_agentcomponent',component:AgentcomponentComponent},
 {path:'c_agentprofile',component:AgentprofileComponent},
 {path:'c_approve-cust',component:ApproveCustComponent},
 {path:'c_viewcustomer',component:ViewcustomerComponent},
 {path:'c_viewtransaction',component:ViewtransactionComponent},
 {path:'c_agentmain',component:AgentmainComponent},
 {path:'customer-profile',component:CustomerProfileComponent},
 { path:'dashboard', component:DashboardComponent },
 { path:'customer',component:b_CustomerComponent},
 { path:'manager',component:ManagerComponent},
 { path:'m-registration',component:MRegistrationComponent},
 {path:'mdupdate',component:MdupdateComponent},
 {path:'faq',component:FaqComponent},
 {path:'terms',component:TermsComponent},
 {path:'a_login', component:SadminloginComponent}, 
 {path:'ceo-main-page', component:CeoMainPageComponent}, 
{ path:'aboutus', component:AboutusComponent },
{ path:'loan', component:LoanComponent },
{ path:'branch', component:BranchComponent },
{ path:'admin', component:AdminComponent },
{ path:'register', component:RegisterComponent },
{ path:'profile', component:ProfileComponent }, 
{path:'d_login',component:d_LoginComponent},
	{path:'d_customer',component:d_CustomerComponent},
	{path:'d_profile',component:d_ProfileComponent},
	{path:'loans',component:LoansComponent},
	{path:'transfer',component:TransferComponent},
	{path:'balance',component:BalanceComponent},
	{path:'mini',component:MiniComponent},
	{path:'requestloan',component: RequestLoanComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }